package com.cg.service;
import java.util.List;
import com.cg.dao.ModuleDao;
import com.cg.dao.ModuleDaoImpl;
import com.cg.dto.AssessmentScore;
import com.cg.dto.TraineeBean;
import com.cg.exception.ModuleScoreException;

public class ModuleServiceImpl implements ModuleService
{
	ModuleDao modDao = new ModuleDaoImpl();
	@Override
	public List<Integer> getAllTrainee() throws ModuleScoreException 
	{
		return modDao.getAllTrainee();
	}

	@Override
	public long setScoreDetails(AssessmentScore assScore)
			throws ModuleScoreException 
	{
		
		return 0;
	}

	@Override
	public List<AssessmentScore> getAllScore()
			throws ModuleScoreException 
	{
		return modDao.getAllScore();
	}
}
