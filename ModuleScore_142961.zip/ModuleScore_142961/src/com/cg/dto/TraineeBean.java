package com.cg.dto;

public class TraineeBean
{
		private int traineeId;
		private String traineeName;
	
/***********************empty constructor***********************/
		public TraineeBean()
		{
			super();
		}
/************************Parameterized constructor********************/

		public TraineeBean(int traineeId, String traineeName) 
		{
			super();
			this.traineeId = traineeId;
			this.traineeName = traineeName;
		}
/**************************Getter Setters***********************/
	
	public int getTraineeId() 
	{
		return traineeId;
	}
	public void setTraineeId(int traineeId) 
	{
		this.traineeId = traineeId;
	}
	public String getTraineeName() 
	{
		return traineeName;
	}
	public void setTraineeName(String traineeName) 
	{
		this.traineeName = traineeName;
	}	
}
