package com.cg.exception;
public class ModuleScoreException extends Exception
{
	public ModuleScoreException() 
	{
		super();
	}
	
	public ModuleScoreException(String message) 
	{
		super(message);
	}

	public ModuleScoreException(Throwable cause) 
	{
		super(cause);
	}
}
