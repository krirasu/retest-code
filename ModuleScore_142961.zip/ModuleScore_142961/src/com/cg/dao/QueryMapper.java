package com.cg.dao;

public interface QueryMapper 
{
	/*
	 * Contains all SQL queries used in Dao Layer
	 */
	String INSERT_SCORE_INFO = "INSERT INTO AssessmentScore(trainee_id,module_name,mpt,mtt,ass_marks,total) VALUES(?, ?, ?, ?, ?, ?)";
	String SELECT_SCORE_INFO = "SELECT * FROM AssessmentScore";
	String SELECT_Trainee_INFO = "SELECT trainee_id FROM Trainees";
}
