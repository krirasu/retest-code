package com.cg.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.DBUtil.DBUtil;
import com.cg.dto.AssessmentScore;
import com.cg.dto.TraineeBean;
import com.cg.exception.ModuleScoreException;

public class ModuleDaoImpl implements ModuleDao
{
	Connection conn;
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.dao.ModuleScoreDao#getAllTrainee()
	 * selects all trainee details from TraineeBean table and returns list of details
	 */
	@Override
	public List<Integer> getAllTrainee() throws ModuleScoreException 
	{
		conn = DBUtil.getConnection();
		List<Integer> tList = new ArrayList<>();
		int temp=0;
		try 
		{
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECT_Trainee_INFO);
			while(rst.next())
			{
				temp=(rst.getInt("id"));
				tList.add(temp);
			}
		} 
		catch (SQLException e) 
		{
			throw new ModuleScoreException("Problem in fetching Trainee list: "+e.getMessage());
		}
		return tList;
	}

	@Override
	public long setScoreDetails(AssessmentScore assScore)
			throws ModuleScoreException 
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public List<AssessmentScore> getAllScore() throws ModuleScoreException {
		conn = DBUtil.getConnection();
		List<AssessmentScore> asList = new ArrayList<>();
		
		try 
		{
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECT_SCORE_INFO);
			while(rst.next())
			{
				AssessmentScore as = new AssessmentScore();
				as.setTraineeId(rst.getInt("id"));
				as.setModuleName(rst.getString("name"));
				as.setMptNo(rst.getInt("mptNo"));
				as.setMttNo(rst.getInt("mttNo"));
				as.setAssMarks(rst.getInt("assMarks"));
				as.setTotal(rst.getInt("total"));
				asList.add(as);
			}
		} 
		catch (SQLException e) 
		{
			throw new ModuleScoreException("Problem in fetching Trainee list: "+e.getMessage());
		}
		return asList;
	}
}
