package com.cg.dao;
import java.util.List;
import com.cg.dto.AssessmentScore;
import com.cg.dto.TraineeBean;
import com.cg.exception.ModuleScoreException;

public interface ModuleDao 
{
	List<Integer> getAllTrainee() throws ModuleScoreException;
	long setScoreDetails(AssessmentScore assScore) throws ModuleScoreException;
	List<AssessmentScore> getAllScore() throws ModuleScoreException;
}
